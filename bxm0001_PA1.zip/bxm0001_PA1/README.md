# Programming Assignment 1:

This assignment includes 5 C Programs that all do not
use any built-in or standard library functions. 

# Compile
Compile and run each program seperately from the next.
SUCH AS:
gcc summation1.c
./a.exe
----test----
gcc summation2.c
./a.exe
----test----
gcc summation3.c
./a.exe
----test----
gcc sentenceInfo.c
./a.exe
----test----
gcc sinComp.c
./a.exe
----test----


# The 5 programs are listed below:

## Summation of (n)
### with 'a' final index and 'n'starting index
test with...
any index value: 1 < a < 10

## Summation of (a^n + b) with 'a' final index
### with 'a' final index and 'n'starting index
test with...
any index value: 1 < a < 10
any b value: 1 < b < 10

## Summation of ((b^n)!) with 'a' final index
### with 'a' final index and 'n'starting index
test with...
any index value: 1 < a < 10
any b value: 1 < b < 10

## Sentence Information Finder
### Finds # of words, # of numbers, & # of input characters
test with...
any sentence with a maximum of
255 input characters (+ \n)

## Computing Sin of (x)
### with 'a' final index and 'n'starting index
test with...
any index value: 1 < a < 10
any x float value
